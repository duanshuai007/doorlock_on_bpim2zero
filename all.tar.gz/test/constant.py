
lll_msg = {
	"name" : "",
	"age" : 0,
	"address" : "",
}

max_number = 100
