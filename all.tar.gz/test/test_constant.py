import constant as c

print(c.max_number)
print(c.lll_msg)


