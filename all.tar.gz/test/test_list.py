
l = [None] * (6*4)
print(l)

l[3] = 178
print(l)
