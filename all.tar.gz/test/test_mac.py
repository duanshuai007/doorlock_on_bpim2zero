import uuid
sn = uuid.UUID(int = uuid.getnode())
print(sn)
